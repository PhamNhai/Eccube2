<?php
/*
 * Copyright(c) 2012 GMO Payment Gateway, Inc. All rights reserved.
 * http://www.gmo-pg.com/
 */

require_once(MDL_PG_MULPAY_CLASS_PATH . 'plugin/LC_Pg2Click.php');

/**
 *
 */
class LC_Pg2Click_Ex extends LC_Pg2Click {


}
