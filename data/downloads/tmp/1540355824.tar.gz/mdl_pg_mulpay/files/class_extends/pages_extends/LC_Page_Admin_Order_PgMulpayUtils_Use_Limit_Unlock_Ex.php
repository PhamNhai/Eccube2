<?php
/*
 * Copyright(c) 2017 GMO Payment Gateway, Inc. All rights reserved.
 * http://www.gmo-pg.com/
 */

require_once(MODULE_REALDIR . 'mdl_pg_mulpay/inc/include.php');
require_once(MDL_PG_MULPAY_CLASS_PATH . 'pages/LC_Page_Admin_Order_PgMulpayUtils_Use_Limit_Unlock.php');

class LC_Page_Admin_Order_PgMulpayUtils_Use_Limit_Unlock_Ex extends LC_Page_Admin_Order_PgMulpayUtils_Use_Limit_Unlock {
}
?>
