<?php
/*
 * Copyright(c) 2012 GMO Payment Gateway, Inc. All rights reserved.
 * http://www.gmo-pg.com/
 */

require_once(MDL_PG_MULPAY_CLASS_PATH . 'client/SC_Mdl_PG_MULPAY_Client_CVS.php');

/**
 * 決済モジュール 決済処理: コンビニ
 */
class SC_Mdl_PG_MULPAY_Client_CVS_Ex extends SC_Mdl_PG_MULPAY_Client_CVS {
}
?>
